﻿define("epi-languagemanager/widget/CreateLanguageBranchSelector", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "epi-languagemanager/widget/CommandSelector"
], function (
// Dojo
    declare,
    lang,

    CommandSelector

) {
    // module:
    //      "epi-languagemanager/widget/CreateLanguageBranchSelector"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([CommandSelector], {

    });
});