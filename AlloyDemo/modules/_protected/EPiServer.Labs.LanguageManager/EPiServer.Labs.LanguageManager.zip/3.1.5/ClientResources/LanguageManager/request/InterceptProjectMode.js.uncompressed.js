﻿define( "epi-languagemanager/request/InterceptProjectMode", [
    "dojo/Deferred"
], function (Deferred) {

    return {
        beforeSend: function (params) {
            // summary:
            //      Change value of header X-EPiCurrentProject of the request parameters with value is the
            //      project-Id which we want to add item to.
            // params: Object
            //      The request parameters
            // tags: public

            var options = params.options;
            options.headers["X-EPiCurrentProject"] = JSON.parse(options.postData).projectId;

            var result = new Deferred();
            result.resolve(params);

            return result.promise;
        }
    };

});
